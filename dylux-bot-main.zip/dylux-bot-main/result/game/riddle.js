[
  { "author" : "FG98",
    "index": 1,
    "soal": " Animales como las lagartijas que pueden cambiar el color de su piel?",
    "jawaban": "Camaleón"
  },
  { "author" : "FG98",
    "index": 2,
    "soal": " Este banco está ocupado por un padre y por un hijo: El padre se llama Juan y el hijo ya te lo he dicho",
    "jawaban": "Esteban"
  },
  { "author" : "FG98",
    "index": 3,
    "soal": " Algunos meses tienen 31 días, otros solo 30.¿Cuantos tienen 28 días?",
    "jawaban": "Todos"
  },
  { "author" : "FG98",
    "index": 4,
    "soal": " En el cielo brinco y vuelo. Me encanta subir, flotar y lucir mi pelo.",
    "jawaban": "Cometa"
  },
  { "author" : "FG98",
    "index": 5,
    "soal": " Carrera de larga distancia 42,195 km?",
    "jawaban": "Maraton"
  },
  { "author" : "FG98",
    "index": 6,
    "soal": " La línea que divide la Tierra en los hemisferios norte y sur?",
    "jawaban": "Ecuador"
  },
  { "author" : "FG98",
    "index": 7,
    "soal": " Somos muchos hermanitos, en una sola casa vivimos, si nos rascan la cabeza al instante morimos",
    "jawaban": "Fósforos"
  },
  { "author" : "FG98",
    "index": 8,
    "soal": "¿Cómo se llama la fuerza de atracción que se produce en el universo, incluida la Tierra?",
    "jawaban": "Gravedad"
  },
  { "author" : "FG98",
    "index": 9,
    "soal": " ¿El nombre de la película que cuenta la historia de un robot que puede convertirse en vehículo?",
    "jawaban": "Transformers"
  },
  { "author" : "FG98",
    "index": 10,
    "soal": " ¿Un luchador en la Antigua Roma que luchó por el entretenimiento público?",
    "jawaban": "Gladiador"
  },
  { "author" : "FG98",
    "index": 11,
    "soal": " ¿El nombre del lujoso barco de pasajeros que se hundió durante su viaje inaugural en 1912?",
    "jawaban": "Titanic"
  },
  { "author" : "FG98",
    "index": 12,
    "soal": " ¿El club de fútbol de Italia que tiene el sobrenombre de Old Lady?,
    "jawaban": "Juventus"
  },
  { "author" : "FG98",
    "index": 13,
    "soal": " ¿El mecanismo del sistema de gobierno estatal basado en la voluntad del pueblo?",
    "jawaban": "Democracia"
  },
  { "author" : "FG98",
    "index": 14,
    "soal": " Es la frustración vertical de un deseo horizontal",
    "jawaban": "Bailar"
  },
  { "author" : "FG98",
    "index": 15,
    "soal": " ¿Cuál es el nombre de la moneda utilizada en Rusia?",
    "jawaban": "Rublo"
  },
  { "author" : "FG98",
    "index": 16,
    "soal": " ¿Ciencias naturales que observan cuerpos celestes y fenómenos fuera de la atmósfera terrestre?",
    "jawaban": "Astronomía"
  },
  { "author" : "FG98",
    "index": 17,
    "soal": " ¿El emperador francés que gobernó Europa en 1803-1815?",
    "jawaban": "Napoleon"
  },
  { "author" : "FG98",
    "index": 18,
    "soal": " ¿Artista español de fama mundial con un género artístico llamado cubismo?",
    "jawaban": "Picasso"
  },
  { "author" : "FG98",
    "index": 19,
    "soal": " ¿El nombre del comandante en jefe de las Fuerzas Aliadas en la Segunda Guerra Mundial?",
    "jawaban": "Eisenhower"
  },
  { "author" : "FG98",
    "index": 20,
    "soal": " ¿Un arma ficticia en el mundo de Star Wars, utilizada por los Jedi y los Sith?",
    "jawaban": "Sabledeluz"
  },
  { "author" : "FG98",
    "index": 21,
    "soal": " ¿El nombre de la península en Europa donde se encuentran los países de Noruega y Suecia?",
    "jawaban": "Skandinavia"
  },
  { "author" : "FG98",
    "index": 22,
    "soal": " ¿El estadio de fútbol de Londres que también es la sede del Arsenal FC?",
    "jawaban": "Emirates"
  },
  { "author" : "FG98",
    "index": 23,
    "soal": " Cantante mundialmente famosa, ¿solía estar en el grupo Destiny's Child?",
    "jawaban": "Beyonce"
  },
  { "author" : "FG98",
    "index": 24,
    "soal": " ¿El término para la creencia de que Dios es uno o uno?",
    "jawaban": "Monoteismo"
  },
  { "author" : "FG98",
    "index": 25,
    "soal": " ¿El nombre del reino donde el rey es actualmente vicegobernador de DI Yogyakarta?",
    "jawaban": "Pakualaman"
  },
  { "author" : "FG98",
    "index": 26,
    "soal": " ¿Llamado uno de los más grandes matemáticos de la historia, nacido en el 287 a. C.?",
    "jawaban": "Archimedes"
  },
  { "author" : "FG98",
    "index": 27,
    "soal": " ¿La cadena montañosa más alta de Indonesia, ubicada en la isla de Papúa?",
    "jawaban": "Jayawijaya"
  },
  { "author" : "FG98",
    "index": 28,
    "soal": " ¿Un grupo de superhéroes de ficción formado por Iron Man, Capitán América, Hulk, Thor?",
    "jawaban": "Vengadores"
  },
  { "author" : "FG98",
    "index": 29,
    "soal": " ¿El nombre de un vasto territorio en Rusia, que cubre casi todo el territorio del norte de Asia?",
    "jawaban": "Siberia"
  },
  { "author" : "FG98",
    "index": 30,
    "soal": " ¿Un objeto o medio que conduce corriente eléctrica con facilidad?",
    "jawaban": "Conductor"
  },
  { "author" : "FG98",
    "index": 31,
    "soal": " ¿El nombre del idioma que se habla en Irán, Tayikistán, Afganistán y Uzbekistán?",
    "jawaban": "Farsi"
  },
  { "author" : "FG98",
    "index": 32,
    "soal": " ¿El área donde hubo la primera práctica agrícola alrededor del 8000 aC?",
    "jawaban": "Mesopotamia"
  },
  { "author" : "FG98",
    "index": 33,
    "soal": " ¿Una ideología basada en el principio de liderazgo con autoridad absoluta?",
    "jawaban": "Fascismo"
  },
  { "author" : "FG98",
    "index": 34,
    "soal": " ¿El nombre del período geológico de hace 252 a 66 millones de años, también llamado Edad de los Reptiles?",
    "jawaban": "Mesozoico"
  },
  { "author" : "FG98",
    "index": 35,
    "soal": " El nombre conocido en la leyenda ¿Respuesta como el arquitecto que diseñó el templo de Borobudur?",
    "jawaban": "Gunadharma"
  },
  { "author" : "FG98",
    "index": 36,
    "soal": " Una danza tradicional china que usa un disfraz que se asemeja a un león.",
    "jawaban": "Danza del leon"
  },
  { "author" : "FG98",
    "index": 37,
    "soal": " ¿Qué término significa el movimiento de personas de las aldeas a las ciudades?",
    "jawaban": "Urbanización"
  },
  { "author" : "FG98",
    "index": 38,
    "soal": " Famoso grupo de música de la década de 1970 de Bandung, ¿el personal son tres hermanos?",
    "jawaban": "Bimbo"
  },
  { "author" : "FG98",
    "index": 39,
    "soal": " Ni torcida ni inclinada tiene que estar la pared, para eso tengo plomada y me ayudo del nivel.",
    "jawaban": "Albañil"
  },
  { "author" : "FG98",
    "index": 40,
    "soal": " ¿Conocido como el “maestro keroncong indonesio”, el creador de la canción Bengawan Solo?",
    "jawaban": "Gesang"
  },
  { "author" : "FG98",
    "index": 41,
    "soal": " ¿La escala de temperatura donde el punto de congelación del agua está en 0 grados y el punto de ebullición está en 100 grados?",
    "jawaban": "Celsius"
  },
  { "author" : "FG98",
    "index": 42,
    "soal": " ¿Espíritus míticos javaneses, en forma de humanos parecidos a simios, grandes y peludos?",
    "jawaban": "Génerouwo"
  },
  { "author" : "FG98",
    "index": 43,
    "soal": " ¿Un distrito de Los Ángeles conocido por su industria cinematográfica mundial?",
    "jawaban": "Hollywood"
  },
  { "author" : "FG98",
    "index": 44,
    "soal": " ¿La rama de la biología que estudia la herencia de rasgos en organismos y suborganismos?",
    "jawaban": "Genética"
  },
  { "author" : "FG98",
    "index": 45,
    "soal": " Un antiguo sitio humano en Java Central, ¿también es Patrimonio de la Humanidad por la UNESCO?",
    "jawaban": "Sangiran"
  },
  { "author" : "FG98",
    "index": 46,
    "soal": " ¿Una roca más pequeña que un planeta en órbita alrededor del Sol?",
    "jawaban": "Asteroides"
  },
  { "author" : "FG98",
    "index": 47,
    "soal": " ¿El término para animales o plantas herbívoros?",
    "jawaban": "Herbívoro"
  },
  { "author" : "FG98",
    "index": 48,
    "soal": " ¿Un término que significa masacre sistemática de una tribu o grupo?",
    "jawaban": "Genocidio"
  },
  { "author" : "FG98",
    "index": 49,
    "soal": " ¿Cómo se llama la enfermedad febril transmitida por la hembra del mosquito Anopheles?",
    "jawaban": "Malaria"
  },
  { "author" : "FG98",
    "index": 50,
    "soal": " ¿El nombre de un personaje de ficción cultural de Sundanese que es divertido, inocente, pero al mismo tiempo inteligente?",
    "jawaban": "Kabayan"
  },
  { "author" : "FG98",
    "index": 51,
    "soal": " ¿El dormitorio donde estudian los estudiantes santri bajo la guía del Kiai?",
    "jawaban": "Internado"
  },
  { "author" : "FG98",
    "index": 52,
    "soal": " ¿Compañía japonesa de videojuegos, creadora de Mario Bros. y Pokémon?",
    "jawaban": "Nintendo"
  },
  { "author" : "FG98",
    "index": 53,
    "soal": " ¿Una religión oficial en Indonesia basada en las enseñanzas de Confucio?",
    "jawaban": "Khong hu cu"
  },
  { "author" : "FG98",
    "index": 54,
    "soal": " ¿El nombre de una enciclopedia en línea que cualquiera puede escribir y editar gratis?",
    "jawaban": "Wikipedia"
  },
  { "author" : "FG98",
    "index": 55,
    "soal": " ¿Formar un cuadrilátero, un par de lados paralelos pero no de la misma longitud?",
    "jawaban": "Trapezoide"
  },
  { "author" : "FG98",
    "index": 56,
    "soal": " ¿Enfermedades en las que la hormona reguladora del azúcar en sangre del cuerpo no es suficiente?",
    "jawaban": "Diabetes"
  },
  { "author" : "FG98",
    "index": 57,
    "soal": " ¿El país independiente más pequeño del mundo reconocido internacionalmente?",
    "jawaban": "Vaticano"
  },
  { "author" : "FG98",
    "index": 58,
    "soal": " ¿Un antiguo imperio en territorio griego gobernado por Alejandro Magno?",
    "jawaban": "Macedónio"
  },
  { "author" : "FG98",
    "index": 59,
    "soal": " ¿El país con la segunda población más musulmana del mundo?",
    "jawaban": "Pakistan"
  },
  { "author" : "FG98",
    "index": 60,
    "soal": " ¿Síntomas de función cerebral disminuida, generalmente ocurre en ancianos?",
    "jawaban": "Demencia"
  },
  { "author" : "FG98",
    "index": 61,
    "soal": " ¿Combustible fósil, utilizado en plantas de energía de vapor?",
    "jawaban": "Carbón"
  },
  { "author" : "FG98",
    "index": 62,
    "soal": " ¿El nombre del famoso templo de Bali que se construyó en la punta de una roca?",
    "jawaban": "Uluwatu"
  },
  { "author" : "FG98",
    "index": 63,
    "soal": " ¿Un título obtenido por el hijo del sultán Agung de Mataram?",
    "jawaban": "Preciso"
  },
  { "author" : "FG98",
    "index": 64,
    "soal": " ¿Una persona encargada de cuidar a bebés o niños en una familia?",
    "jawaban": "azafata"
  },
  { "author" : "FG98",
    "index": 65,
    "soal": " D¿El área de Japón donde ocurrió la fuga nuclear en 2011?",
    "jawaban": "Fukushima"
  },
  { "author" : "FG98",
    "index": 66,
    "soal": " ¿Protección financiera para la vida, la salud, la propiedad, etc.?",
    "jawaban": "Seguro"
  },
  { "author" : "FG98",
    "index": 67,
    "soal": " P¿La empresa italiana del logotipo del caballo es un fabricante de supercoches y coches de carreras?",
    "jawaban": "Ferrari"
  },
  { "author" : "FG98",
    "index": 68,
    "soal": " ¿Una tribu del sur de Sulawesi que es famosa por ser un marinero consumado?",
    "jawaban": "BugisVampir yang"
  },
  { "author" : "FG98",
    "index": 69,
    "soal": " ¿El vampiro que es el personaje principal de la ficción de Bram Stoker?",
    "jawaban": "Drácula"
  },
  { "author" : "FG98",
    "index": 70,
    "soal": " ¿Este planeta es el planeta más grande del Sistema Solar?",
    "jawaban": "Júpiter"
  },
  { "author" : "FG98",
    "index": 71,
    "soal": " ¿Qué plantas se usaban para fabricar papel en el Antiguo Egipto?",
    "jawaban": "Papiro"
  },
  { "author" : "FG98",
    "index": 72,
    "soal": " ¿Explosivos en forma de una mezcla en polvo de azufre, carbón vegetal y nitrato de potasio?",
    "jawaban": "Pólvora"
  },
  { "author" : "FG98",
    "index": 73,
    "soal": " ¿El idioma oficial que también se habla ampliamente en Filipinas?",
    "jawaban": "Tagalo"
  },
  { "author" : "FG98",
    "index": 74,
    "soal": " Un pequeño país de América del Sur, ¿hay muchos descendientes de Java?",
    "jawaban": "Surinam"
  },
  { "author" : "FG98",
    "index": 75,
    "soal": " ¿El semental alado de la mitología griega?",
    "jawaban": "Pegaso"
  },
  { "author" : "FG98",
    "index": 76,
    "soal": " Banda de rock alternativo de Londres. vocalista llamado Chris Martin?",
    "jawaban": "Coldplay"
  },
  { "author" : "FG98",
    "index": 77,
    "soal": " ¿Qué fruta cortada tiene una sección transversal en forma de estrella?",
    "jawaban": "Fruta estrella"
  },
  { "author" : "FG98",
    "index": 78,
    "soal": " ¿Un conjunto musical que suele contar con metalófonos, xilófonos, tambores y gongs?",
    "jawaban": "Gamelan"
  },
  { "author" : "FG98",
    "index": 79,
    "soal": " ¿El nombre de la ciudad por la que durante varios siglos se debatió el islam, el cristianismo, el judaísmo?",
    "jawaban": "Jerusalén"
  },
  { "author" : "FG98",
    "index": 80,
    "soal": " ¿El idioma oficial de Bangladesh, hablado por unos 200 millones de personas?",
    "jawaban": "Bengali"
  },
  { "author" : "FG98",
    "index": 81,
    "soal": " ¿Una bebida embriagadora hecha de etanol?",
    "jawaban": "Alcohol"
  },
  { "author" : "FG98",
    "index": 82,
    "soal": " ¿El único volcán activo en Europa continental se encuentra en Italia?",
    "jawaban": "Vesubio"
  },
  { "author" : "FG98",
    "index": 83,
    "soal": " ¿Un personaje de ficción con el pelo muy largo, el protagonista principal de la película animada Enredados?",
    "jawaban": "Rapunzel"
  },
  { "author" : "FG98",
    "index": 84,
    "soal": " ¿Desastres naturales en forma de grandes olas del mar?",
    "jawaban": "Tsunami"
  },
  { "author" : "FG98",
    "index": 85,
    "soal": " ¿El nombre de la ciudad en el antiguo estado turco llamado Constantinopla?",
    "jawaban": "Estanbul"
  },
  { "author" : "FG98",
    "index": 86,
    "soal": " ¿La subespecie humana que se extinguió de la faz de la tierra hace unos 30.000 años?",
    "jawaban": "Neandertales"
  },
  { "author" : "FG98",
    "index": 87,
    "soal": " ¿El nombre del ritual de suicidio de los samuráis en Japón al desgarrar el estómago?",
    "jawaban": "Seppuku"
  },
  { "author" : "FG98",
    "index": 88,
    "soal": " ¿El tipo de queso de Italia que se encuentra a menudo en los platos de pizza?",
    "jawaban": "Queso Mozzarella"
  },
  { "author" : "FG98",
    "index": 89,
    "soal": " ¿Título para la esposa de un monarca (rey, sultán o emperador)?",
    "jawaban": "Emperatriz"
  },
  { "author" : "FG98",
    "index": 90,
    "soal": " ¿El nombre de la tribu que ha habitado durante mucho tiempo el Polo Norte de la Tierra?",
    "jawaban": "esquimal"
  },
  { "author" : "FG98",
    "index": 91,
    "soal": " ¿El segundo elemento más abundante después del oxígeno en el cuerpo humano?",
    "jawaban": "Carbón"
  },
  { "author" : "FG98",
    "index": 92,
    "soal": " ¿El genocidio contra los judíos europeos durante la Segunda Guerra Mundial?",
    "jawaban": "Holocausto"
  },
  { "author" : "FG98",
    "index": 93,
    "soal": " ¿Cuál es el proceso de conversión de azúcar en etanol mediante levadura?",
    "jawaban": "Fermentación"
  },
  { "author" : "FG98",
    "index": 94,
    "soal": " ¿Adivinación en la tradición javanesa que discute la existencia de una reina justa?",
    "jawaban": "Jayabaya"
  },
  { "author" : "FG98",
    "index": 95,
    "soal": " ¿Figura polaca del siglo XV que acuñó la teoría del heliocentrismo?",
    "jawaban": "Copérnico"
  },
  { "author" : "FG98",
    "index": 96,
    "soal": " ¿Una herramienta popular para unir dos lados de la tela, utilizada en ropa, bolsos, etc.?",
    "jawaban": "Cremallera"
  },
  { "author" : "FG98",
    "index": 97,
    "soal": " ¿La unidad de diferencia de potencial eléctrico entre dos puntos en un circuito eléctrico?",
    "jawaban": "Voltaje"
  },
  { "author" : "FG98",
    "index": 98,
    "soal": " ¿Un sistema social que le dio un gran poder a la nobleza?",
    "jawaban": "Feudalismo"
  },
  { "author" : "FG98",
    "index": 99,
    "soal": " ¿El nombre del edulcorante artificial / sintético que se compone de dos tipos de aminoácidos?",
    "jawaban": "Aspartamo"
  },
  { "author" : "FG98",
    "index": 100,
    "soal": " ¿La primera consola de videojuegos producida por Sony en la década de 1990?",
    "jawaban": "PlayStation"
  },
  { "author" : "FG98",
    "index": 101,
    "soal": " ¿Otro nombre para la isla de Borneo, usado durante el reinado de las Indias Orientales Holandesas?",
    "jawaban": "Borneo"
  },
  { "author" : "FG98",
    "index": 102,
    "soal": " ¿Una piedra preciosa o piedra preciosa cuyo color está en el rango verde?",
    "jawaban": "Esmeralda"
  },
  { "author" : "FG98",
    "index": 103,
    "soal": " ¿El nombre del museo de historia y cultura javanesa en Yogyakarta?",
    "jawaban": "Sonobudoyo"
  },
  { "author" : "FG98",
    "index": 104,
    "soal": " ¿La rama de la ciencia médica que estudia aspectos de la salud del cuerpo y el alma humanos?",
    "jawaban": "Psiquiatría"
  },
  { "author" : "FG98",
    "index": 105,
    "soal": " ¿El primer presidente de Estados Unidos, también el nombre de la capital de Estados Unidos?",
    "jawaban": "Washingthon"
  },
  { "author" : "FG98",
    "index": 106,
    "soal": " ¿El único tipo de mamífero que puede volar?",
    "jawaban": "Murciélago"
  },
  { "author" : "FG98",
    "index": 107,
    "soal": " Archipiélago de Oceanía, formado por más de 1000 islas?",
    "jawaban": "Polinesia"
  },
  { "author" : "FG98",
    "index": 108,
    "soal": " El título del monarca de la era del reino, ¿el nivel es equivalente al emperador?",
    "jawaban": "Maharaja"
  },
  { "author" : "FG98",
    "index": 109,
    "soal": " ¿El nombre de la isla más cercana a Singapur?",
    "jawaban": "Batam"
  },
  { "author" : "FG98",
    "index": 110,
    "soal": " ¿Rama de las fuerzas armadas capaz de realizar incursiones anfibias?",
    "jawaban": "Infantería de marina"
  },
  { "author" : "FG98",
    "index": 111,
    "soal": " ¿La empresa operadora de telefonía celular en Indonesia con más suscriptores?",
    "jawaban": "Telkomsel"
  },
  { "author" : "FG98",
    "index": 112,
    "soal": " ¿Cómo se llama el animal con caparazón de 10 patas?",
    "jawaban": "Cangrejo"
  },
  { "author" : "FG98",
    "index": 113,
    "soal": " ¿Objetos en miniatura para representar una escena o una escena?",
    "jawaban": "Diorama"
  },
  { "author" : "FG98",
    "index": 114,
    "soal": " Casa tradicional de Toraja, el techo es curvo como un barco?",
    "jawaban": "Tonkonan"
  },
  { "author" : "FG98",
    "index": 115,
    "soal": " ¿La cueva que se convirtió en la sede del príncipe Diponegoro en 1825?",
    "jawaban": "Selarong"
  },
  { "author" : "FG98",
    "index": 116,
    "soal": " ¿El nombre de una criatura en forma de mujer que vive en el cielo?",
    "jawaban": "Ángel"
  },
  { "author" : "FG98",
    "index": 117,
    "soal": " ¿La espada curva de un solo filo que usaba el samurái japonés?",
    "jawaban": "Katana"
  },
  { "author" : "FG98",
    "index": 118,
    "soal": " ¿Material de joyería producido en el tejido blando de un animal molusco?",
    "jawaban": "Perla"
  },
  { "author" : "FG98",
    "index": 119,
    "soal": " ¿El nombre de la empresa del desarrollador de juegos finlandés Clash of Clans?",
    "jawaban": "Supercell"
  },
  { "author" : "FG98",
    "index": 120,
    "soal": " ¿Una bebida tradicional de Sundan, hecha de azúcar de palma y leche de coco?",
    "jawaban": "Bajigur"
  },
  { "author" : "FG98",
    "index": 121,
    "soal": " ¿El género musical que se desarrolló originalmente en Jamaica en la década de 1960?",
    "jawaban": "Reggae"
  },
  { "author" : "FG98",
    "index": 122,
    "soal": " Drama tradicional de Java Oriental, ¿es entretenido y te hace reír?",
    "jawaban": "Ludruk"
  },
  { "author" : "FG98",
    "index": 123,
    "soal": " ¿El nombre del dormitorio de la escuela ficticia donde los personajes de Harry Potter estudian magia??",
    "jawaban": "Hogwarts"
  },
  { "author" : "FG98",
    "index": 124,
    "soal": " ¿La ciudad cuyo nombre proviene de su historia como fabricante de terasi?",
    "jawaban": "Cirebon"
  },
  { "author" : "FG98",
    "index": 125,
    "soal": " ¿Un funcionario público en el ámbito jurídico que esté autorizado para realizar una escritura pública?",
    "jawaban": "Notario público"
  },
  { "author" : "FG98",
    "index": 126,
    "soal": " ¿Qué tipo de azúcar procesa el cuerpo humano a partir de los carbohidratos?",
    "jawaban": "Glucosa"
  },
  { "author" : "FG98",
    "index": 127,
    "soal": " ¿Un pequeño cuchillo de mano con una forma curva típica del sudeste asiático?",
    "jawaban": "Kerambit"
  },
  { "author" : "FG98",
    "index": 128,
    "soal": " ¿Una antigua especie de elefante del género mamut, que comía hojas y ramas de árboles?",
    "jawaban": "Mastodonte"
  },
  { "author" : "FG98",
    "index": 129,
    "soal": " ¿El juramento hecho por Gajah Mada en la ceremonia de su nombramiento como Patih?",
    "jawaban": "Palapa"
  },
  { "author" : "FG98",
    "index": 130,
    "soal": " ¿Depositar productos en el banco, los retiros solo se pueden hacer en determinados momentos?",
    "jawaban": "Depositar"
  },
  { "author" : "FG98",
    "index": 131,
    "soal": " ¿Fenómenos ópticos y meteorológicos en forma de luz multicolor que aparece en el cielo?",
    "jawaban": "Arcoíris"
  },
  { "author" : "FG98",
    "index": 132,
    "soal": " ¿Armas de cohetes militares que tienen un sistema de control automático para encontrar objetivos?",
    "jawaban": "Misil"
  },
  { "author" : "FG98",
    "index": 133,
    "soal": " ¿Sindicatos del crimen organizado en Japón que tienen sus propias formas y leyes?",
    "jawaban": "Yakuza"
  },
  { "author" : "FG98",
    "index": 134,
    "soal": " ¿La clase intelectual que también es un grupo de trabajo o de color en el hinduismo?",
    "jawaban": "Brahmán"
  },
  { "author" : "FG98",
    "index": 135,
    "soal": " ¿La estación seca en los trópicos influenciada por el sistema monzónico?",
    "jawaban": "sequía"
  },
  { "author" : "FG98",
    "index": 136,
    "soal": " ¿Escuelas públicas cuyo plan de estudios contiene lecciones islámicas?",
    "jawaban": "Madrasa"
  },
  { "author" : "FG98",
    "index": 137,
    "soal": " ¿Las plantas que pueden crecer sin agua durante mucho tiempo, existen en áreas desérticas?",
    "jawaban": "Cactus"
  },
  { "author" : "FG98",
    "index": 138,
    "soal": " ¿Una orden de mamíferos de cinco dedos, incluidos lémures, simios y humanos?",
    "jawaban": "primates"
  },
  { "author" : "FG98",
    "index": 139,
    "soal": " ¿Blusa tradicional de mujer hecha de material fino, usada con un pareo o batik?",
    "jawaban": "Kebaya"
  },
  { "author" : "FG98",
    "index": 140,
    "soal": " Tipos de proteína que normalmente se encuentra en el trigo, ¿los celíacos evitan?",
    "jawaban": "Gluten"
  },
  { "author" : "FG98",
    "index": 141,
    "soal": " ¿Un deporte marcial desarrollado por africanos en Brasil en el siglo XVI?",
    "jawaban": "Capoeira"
  },
  { "author" : "FG98",
    "index": 142,
    "soal": " ¿La erosión de sólidos como rocas / suelo debido al transporte de viento, agua o hielo?",
    "jawaban": "Erosión"
  },
  { "author" : "FG98",
    "index": 143,
    "soal": " El pescado, que es un pariente cercano del atún, a menudo se procesa en galletas saladas, albóndigas, pempek.",
    "jawaban": "Caballa"
  },
  { "author" : "FG98",
    "index": 144,
    "soal": " ¿Un tipo de baile social tradicional de Sundan, especialmente en el área de Karawang?",
    "jawaban": "Jaipongan"
  },
  { "author" : "FG98",
    "index": 145,
    "soal": " ¿Sistema numérico en el que los números se escriben con dos símbolos, 0 y 1?",
    "jawaban": "Binario"
  },
  { "author" : "FG98",
    "index": 146,
    "soal": " Especia de las semillas de la familia del jengibre, ¿es la tercera especia más cara del mundo?",
    "jawaban": "Cardamomo"
  },
  { "author" : "FG98",
    "index": 147,
    "soal": " ¿El continente que cubre el Polo Sur de la Tierra tiene una temperatura muy baja?",
    "jawaban": "Antártida"
  },
  { "author" : "FG98",
    "index": 148,
    "soal": " ¿El arma arrojadiza que fue ampliamente utilizada en la Edad Media para destruir muros?",
    "jawaban": "Trebuchet"
  },
  { "author" : "FG98",
    "index": 149,
    "soal": " ¿Copos blancos que son exfoliación excesiva de piel muerta en la cabeza?",
    "jawaban": "Caspa"
  },
  { "author" : "FG98",
    "index": 150,
    "soal": " ¿La ciencia que estudia el lenguaje en manuscritos antiguos?",
    "jawaban": "Filología"
  },
  { "author" : "FG98",
    "index": 151,
    "soal": " ¿Leche que solo se produce en las últimas etapas del embarazo unos días después del parto?",
    "jawaban": "Calostro"
  },
  { "author" : "FG98",
    "index": 152,
    "soal": " ¿Una planta originaria de Japón tiene un sabor fuerte / picante que se come como saborizante en la cocina japonesa?",
    "jawaban": "Wasabi"
  },
  { "author" : "FG98",
    "index": 153,
    "soal": " ¿Un deporte que usa un bate, el campo es cuadrado?",
    "jawaban": "Béisbol"
  },
  { "author" : "FG98",
    "index": 154,
    "soal": " ¿Una especia típica de la cocina Toba Batak, también conocida como pimienta Batak?",
    "jawaban": "Andaliman"
  },
  { "author" : "FG98",
    "index": 155,
    "soal": " ¿El sistema de gobierno adoptado por el Reino Unido, Japón, los Países Bajos, Malasia, Singapur?",
    "jawaban": "parlamentario"
  },
  { "author" : "FG98",
    "index": 156,
    "soal": " ¿Comida tradicional coreana en forma de verduras fermentadas en escabeche con condimentos picantes?",
    "jawaban": "Kimchi"
  },
  { "author" : "FG98",
    "index": 157,
    "soal": " ¿El término para algo que tiene propósitos sociales o ambientales, no una ganancia material?",
    "jawaban": "Sin ánimo de lucro"
  },
  { "author" : "FG98",
    "index": 158,
    "soal": " ¿Un movimiento que lucha por la igualdad de las mujeres en política, economía, cultura, etc.?",
    "jawaban": "Feminismo"
  },
  { "author" : "FG98",
    "index": 159,
    "soal": " ¿Un té fermentado y una bebida azucarada del este de Asia?",
    "jawaban": "Kombucha"
  },
  { "author" : "FG98",
    "index": 160,
    "soal": " ¿Los partidarios de la línea dura de Rusia en 1903 que piensan que el cambio debe ganarse con armas?",
    "jawaban": "Bolchevique"
  },
  { "author" : "FG98",
    "index": 161,
    "soal": " ¿El nombre de la isla volcánica en medio del lago Toba, en el norte de Sumatra?",
    "jawaban": "Samosir"
  },
  { "author" : "FG98",
    "index": 162,
    "soal": " ¿Soldados en la antigua Grecia, funcionando como lanceros en una formación de falange?",
    "jawaban": "Hoplitas"
  },
  { "author" : "FG98",
    "index": 163,
    "soal": " ¿El nombre de una semana que consta de 5 días en la cultura javanesa y balinesa?",
    "jawaban": "Pancawara"
  },
  { "author" : "FG98",
    "index": 164,
    "soal": " ¿Cómo servir comida durante el período colonial holandés con una variedad de platos indonesios?",
    "jawaban": "Rijsttafel"
  },
  { "author" : "FG98",
    "index": 165,
    "soal": " ¿El término para el cultivo con agua sin usar suelo?",
    "jawaban": "Hidroponia"
  },
  { "author" : "FG98",
    "index": 166,
    "soal": " El metal más abundante en la Tierra, ¿es el mejor conductor de electricidad?",
    "jawaban": "Aluminio"
  },
  { "author" : "FG98",
    "index": 167,
    "soal": " ¿Una organización económica basada en la economía de las personas y el principio de parentesco?",
    "jawaban": "Cooperativa"
  },
  { "author" : "FG98",
    "index": 168,
    "soal": " ¿Fiestas hindúes, celebradas cada 210 días utilizando cálculos del calendario balinés?",
    "jawaban": "Galungan"
  },
  { "author" : "FG98",
    "index": 169,
    "soal": "¿La ciencia que estudia la forma de la superficie terrestre así como la superficie de los planetas, satélites naturales, asteroides?",
    "jawaban": "Topografía"
  },
  { "author" : "FG98",
    "index": 170,
    "soal": " ¿Ofrendas a dioses o espíritus ancestrales por parte de seguidores de creencias antiguas en Indonesia?",
    "jawaban": "ofrendas"
  },
  { "author" : "FG98",
    "index": 171,
    "soal": " JEl título de la canción popular coreana, así como el símbolo de Corea, ¿se conoce en Corea del Norte y del Sur?",
    "jawaban": "Arirang"
  },
  { "author" : "FG98",
    "index": 172,
    "soal": " ¿El término forma de pueblo nómada que elige vivir una vida nómada para sobrevivir?",
    "jawaban": "Nómada"
  },
  { "author" : "FG98",
    "index": 173,
    "soal": " ¿Un tipo raro de hongo de pino que es un ingrediente alimenticio de lujo caro en Japón?",
    "jawaban": "Matsutake"
  },
  { "author" : "FG98",
    "index": 174,
    "soal": " Una costumbre comunitaria que regula el flujo de la descendencia proviene del lado materno",
    "jawaban": "Matrilineal"
  },
  { "author" : "FG98",
    "index": 175,
    "soal": " ¿Un prado lleno de arbustos y algún tipo de árbol que crece extendido?",
    "jawaban": "Sabana"
  },
  { "author" : "FG98",
    "index": 176,
    "soal": " ¿El explorador italiano que descubrió América en 1492?",
    "jawaban": "Capoeira"
  },
  { "author" : "FG98",
    "index": 177,
    "soal": " ¿La puntuación o escala utilizada para evaluar el estado de salud del recién nacido?",
    "jawaban": "Apgar"
  },
  { "author" : "FG98",
    "index": 178,
    "soal": " ¿Una de las islas del norte de Sulawesi que tiene la mayor biodiversidad marina del mundo?",
    "jawaban": "Bunaken"
  },
  { "author" : "FG98",
    "index": 179,
    "soal": " ¿Experto en aplicar la ciencia financiera y la teoría estadística a problemas empresariales reales?",
    "jawaban": "Actuario"
  },
  { "author" : "FG98",
    "index": 180,
    "soal": " ¿La tradición de los novios pidiendo bendiciones a los padres de ambas partes?",
    "jawaban": "Sungkem"
  },
  { "author" : "FG98",
    "index": 181,
    "soal": " ¿Qué tipo de salsa blanca hecha de aceite vegetal, huevos de gallina y vinagre?",
    "jawaban": "Mayonesa"
  },
  { "author" : "FG98",
    "index": 182,
    "soal": " ¿Un término que significa no voto o actitud en una votación?",
    "jawaban": "abstenerse"
  },
  { "author" : "FG98",
    "index": 183,
    "soal": " ¿Una de las flores nacionales de Indonesia tiene el apodo de puspa de la nación?",
    "jawaban": "Jazmín"
  },
  { "author" : "FG98",
    "index": 184,
    "soal": " Un instrumento de cuerda que se toca punteando, ¿viene de Rote, NTT?",
    "jawaban": "Sasando"
  },
  { "author" : "FG98",
    "index": 185,
    "soal": " ¿La roca que cuelga y gotea del techo de una cueva de piedra caliza?",
    "jawaban": "Estalactitas"
  },
  { "author" : "FG98",
    "index": 186,
    "soal": " ¿El icono del estado de Singapur en forma de estatua con cabeza de león y cuerpo de pez?",
    "jawaban": "Merlion"
  },
  { "author" : "FG98",
    "index": 187,
    "soal": " ¿El término en el ajedrez cuando la posición del rey no puede separarse del movimiento del oponente?",
    "jawaban": "Mate"
  },
  { "author" : "FG98",
    "index": 188,
    "soal": " ¿Un instrumento para medir la presión del aire, utilizado en la predicción meteorológica?",
    "jawaban": "Barómetro"
  },
  { "author" : "FG98",
    "index": 189,
    "soal": " ¿El 32º presidente de Estados Unidos, el único que ha sido elegido 4 veces?",
    "jawaban": "Roosevelt"
  },
  { "author" : "FG98",
    "index": 190,
    "soal": " ¿Qué tipo de casa arquitectónica tradicional javanesa se construye a partir de cuatro pilares principales?",
    "jawaban": "Limasan"
  },
  { "author" : "FG98",
    "index": 191,
    "soal": " ¿El término japonés para los caracteres de imágenes que se utilizan en los mensajes electrónicos?",
    "jawaban": "Emoji"
  },
  { "author" : "FG98",
    "index": 192,
    "soal": " ¿Una de las típicas dagas indonesias cuyas hojas a menudo se enrollan?",
    "jawaban": "Kris"
  },
  { "author" : "FG98",
    "index": 193,
    "soal": " ¿Un nativo del continente australiano caracterizado por piel oscura y cabello rizado?",
    "jawaban": "Aborigin"
  },
  { "author" : "FG98",
    "index": 194,
    "soal": " T¿Un baile típico de la tribu Gayo de Aceh, realizado para celebrar un evento importante?",
    "jawaban": "Danza saman"
  },
  { "author" : "FG98",
    "index": 195,
    "soal": " ¿La forma joven de insectos o anfibios cuyo desarrollo es por metamorfosis?",
    "jawaban": "Larva"
  },
  { "author" : "FG98",
    "index": 196,
    "soal": " ¿Dónde está amarrado el barco en el puerto para la carga y descarga de mercancías?",
    "jawaban": "Muelle"
  },
  { "author" : "FG98",
    "index": 197,
    "soal": " ¿Qué tipo de reloj funciona con un motor eléctrico o con pilas?",
    "jawaban": "Cuarzo"
  },
  { "author" : "FG98",
    "index": 198,
    "soal": " ¿Tribus hindúes que viven alrededor de las montañas de Bromo y Semeru?",
    "jawaban": "perca"
  },
  { "author" : "FG98",
    "index": 199,
    "soal": " ¿Un juguete que puede girar sobre un eje y estar en equilibrio en un punto?",
    "jawaban": "Cima"
  },
  { "author" : "FG98",
    "index": 200,
    "soal": " ¿Qué legumbres son la principal fuente de proteína vegetal del mundo?",
    "jawaban": "Soja"
  },
  { "author" : "FG98",
    "index": 201,
    "soal": " ¿Un líquido incoloro e inodoro utilizado como arma química de destrucción masiva?",
    "jawaban": "Sarin"
  },
  { "author" : "FG98",
    "index": 202,
    "soal": " ¿La rama de la odontología que se especializa en la ciencia de enderezar los dientes?",
    "jawaban": "ortodoncia"
  },
  { "author" : "FG98",
    "index": 203,
    "soal": " ¿Un término que viene del italiano, que significa bailarina de ballet?",
    "jawaban": "bailarina"
  },
  { "author" : "FG98",
    "index": 204,
    "soal": " ¿Terrazas de arroz en Bali reconocidas por la UNESCO como Patrimonio Cultural de la Humanidad?",
    "jawaban": "Jatiluwih"
  },
  { "author" : "FG98",
    "index": 205,
    "soal": " ¿Un alimento básico que sustituye al arroz elaborado con mandioca o mandioca?",
    "jawaban": "Tiwul"
  },
  { "author" : "FG98",
    "index": 206,
    "soal": " ¿Qué parte del ojo convierte la luz en señales nerviosas?",
    "jawaban": "Retina"
  },
  { "author" : "FG98",
    "index": 207,
    "soal": " ¿Cómo se llamaba la máquina de codificación utilizada por la Alemania nazi en la Segunda Guerra Mundial?",
    "jawaban": "Enigma"
  },
  { "author" : "FG98",
    "index": 208,
    "soal": " ¿Cosméticos hechos de cera, pigmento, aceite, aplicados a los labios?",
    "jawaban": "Lápiz labial"
  },
  { "author" : "FG98",
    "index": 209,
    "soal": " ¿Condimento alimenticio elaborado con soja fermentada, harina y sal?",
    "jawaban": "Taco"
  },
  { "author" : "FG98",
    "index": 210,
    "soal": " ¿Microorganismos que pueden reducir la productividad de los animales que alimentan?",
    "jawaban": "Parásito"
  },
  { "author" : "FG98",
    "index": 211,
    "soal": " ¿El dulce líquido que producen las flores para atraer a los polinizadores?",
    "jawaban": "Néctar"
  },
  { "author" : "FG98",
    "index": 212,
    "soal": " ¿El proceso de hacer nuevas tierras a partir del lecho marino o del lecho de un río?",
    "jawaban": "Recuperación"
  },
  { "author" : "FG98",
    "index": 213,
    "soal": " I¿Cuál es el término para el estado de intención antes de realizar el Hayy o la Umrah?",
    "jawaban": "Ihram"
  },
  { "author" : "FG98",
    "index": 214,
    "soal": " Instrumento de cuerda típico de la tribu Banjar, que se toca con púas?",
    "jawaban": "urgente"
  },
  { "author" : "FG98",
    "index": 215,
    "soal": " ¿La mortal enfermedad viral que asoló África occidental en 2014?",
    "jawaban": "Ebola"
  },
  { "author" : "FG98",
    "index": 216,
    "soal": " ¿El tipo de hurón que se sabe que come granos de café enteros?",
    "jawaban": "Mangosta"
  },
  { "author" : "FG98",
    "index": 217,
    "soal": " ¿El nombre de la espada que tenía el rey Arturo según la mitología británica?",
    "jawaban": "Excalibur"
  },
  { "author" : "FG98",
    "index": 218,
    "soal": " ¿Un país que tiene una bandera roja y blanca como Indonesia?",
    "jawaban": "Mónaco"
  },
  { "author" : "FG98",
    "index": 219,
    "soal": " ¿Una representación teatral con gestos silenciosos?",
    "jawaban": "Pantomima"
  },
  { "author" : "FG98",
    "index": 220,
    "soal": " ¿La tradición nupcial de los novios no permite salir de casa?",
    "jawaban": "Reclusión"
  },
  { "author" : "FG98",
    "index": 221,
    "soal": " ¿Qué tipo de animal está activo por la noche y duerme durante el día?",
    "jawaban": "Nocturno"
  },
  { "author" : "FG98",
    "index": 222,
    "soal": " ¿Trastornos congénitos de la ausencia del pigmento melanina en los ojos, piel, cabello?",
    "jawaban": "Albinismo"
  },
  { "author" : "FG98",
    "index": 223,
    "soal": " ¿La rama de la lingüística que estudia el origen de las palabras?",
    "jawaban": "Etimología"
  },
  { "author" : "FG98",
    "index": 224,
    "soal": " Tipos de peces que pueden saltar a la orilla, que se encuentran en la isla de Borneo?",
    "jawaban": "Disparo"
  },
  { "author" : "FG98",
    "index": 225,
    "soal": " ¿Una moneda electrónica con tecnología blockchain creada en 2009?",
    "jawaban": "Bitcoin"
  },
  { "author" : "FG98",
    "index": 226,
    "soal": " ¿El mayor empresario de cigarrillos en 1918, propietario de una fábrica de kretek de tres pacas?",
    "jawaban": "Nitisemito"
  },
  { "author" : "FG98",
    "index": 227,
    "soal": " ¿Este pintor expresionista es conocido como el maestro de la pintura indonesia?",
    "jawaban": "Affandi"
  }
]
